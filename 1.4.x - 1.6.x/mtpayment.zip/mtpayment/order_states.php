<?php

$order_states_names = array(
    'en' => 'Awaiting MisterTango payment',
    'lt' => 'Laukiamas MisterTango apmokėjimas',
);
